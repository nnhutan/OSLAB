#include <linux/kernel.h>
#include <linux/sched.h>
#include <linux/sched/signal.h>
#include <linux/syscalls.h>

struct proc_info {
	pid_t pid;
	char name[16];
};

struct procinfos {
	long studentID;
	struct proc_info proc;
	struct proc_info parent_proc;
	struct proc_info oldest_child_proc;
};

SYSCALL_DEFINE2(get_proc_info, pid_t, pid, struct procinfos *, info) {
	struct task_struct *current_proc;
	struct task_struct *parent;
	struct task_struct *child;
	parent = NULL;
	child = NULL;
	info->studentID = 1915040;

	if (pid == -1) pid = current->pid;

	//FIND PROCESS WITH ID = PID
	current_proc = find_get_task_by_vpid(pid);

	//FIND PARENT PROCESS & OLDEST CHILDREN PROCESS
	if (current_proc != NULL) {
		//FIND OLDEST CHILDREN PROCESS
		struct list_head *it;
		struct task_struct *temp;
		u64 minimum_start_time = 0;
		bool flag = 0; // flag to set time
		// the oldest children process has minimum start time.
		list_for_each(it, &current->children) {
			temp = list_entry(it, struct task_struct, sibling);
			if (!flag || temp->start_time < minimum_start_time) {
				flag = 1;
				minimum_start_time = temp->start_time;
				child = temp;	
			}
		}

		if (child == NULL) {
			info->oldest_child_proc.pid = -1;
			info->oldest_child_proc.name[0] = '\0';
		} else {
			info->oldest_child_proc.pid = child->pid;
			strcpy(info->oldest_child_proc.name, child->comm);
		}

		//SET INFO OF PROC
		info->proc.pid = current_proc->pid;
		strcpy(info->proc.name, current_proc->comm);

		//FIND PARENT PROCESS
		parent = current->real_parent;
		if (parent == NULL) {
			info->parent_proc.pid = -1;
			info->parent_proc.name[0] = '\0';
		} else {
			info->parent_proc.pid = parent->pid;
			strcpy(info->parent_proc.name, parent->comm);
		}
	}
	else return EINVAL;

	return 0;
}
