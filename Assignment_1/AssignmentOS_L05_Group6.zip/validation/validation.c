#include <get_proc_info.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <stdint.h>

int main(){
	pid_t mypid = getpid ();
	printf("PID: %d\n", mypid);
	struct procinfos info;
	if (get_proc_info(mypid, &info) == 0) {
		printf("StudenID: %ld\n", info.studentID);
		printf("Current process: Name = '%s'\t pid = %d\n", info.proc.name, info.proc.pid);
		printf("Parent process: Name = '%s'\t pid = %d\n", info.parent_proc.name, info.parent_proc.pid);
		printf("Oldest child process: Name = '%s'\t pid =  %d\n", info.oldest_child_proc.name, info.oldest_child_proc.pid);
	} else {
		printf("Cannot get information from the process %d\n", mypid);
	}
	// If necessary , uncomment the following line to make this program run
	// long enough so that we could check out its dependence
	sleep (10);
}
